/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
extern UART_HandleTypeDef huart1;
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */


/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED_BP_Pin GPIO_PIN_13
#define LED_BP_GPIO_Port GPIOC
#define D0_Pin GPIO_PIN_3
#define D0_GPIO_Port GPIOA
#define D1_Pin GPIO_PIN_4
#define D1_GPIO_Port GPIOA
#define D2_Pin GPIO_PIN_5
#define D2_GPIO_Port GPIOA
#define D3_Pin GPIO_PIN_6
#define D3_GPIO_Port GPIOA
#define D4_Pin GPIO_PIN_7
#define D4_GPIO_Port GPIOA
#define D5_Pin GPIO_PIN_0
#define D5_GPIO_Port GPIOB
#define D6_Pin GPIO_PIN_1
#define D6_GPIO_Port GPIOB
#define D7_Pin GPIO_PIN_2
#define D7_GPIO_Port GPIOB
#define D8_Pin GPIO_PIN_10
#define D8_GPIO_Port GPIOB
#define D9_Pin GPIO_PIN_11
#define D9_GPIO_Port GPIOB
#define D10_Pin GPIO_PIN_12
#define D10_GPIO_Port GPIOB
#define D11_Pin GPIO_PIN_13
#define D11_GPIO_Port GPIOB
#define EOC_NEGADO_Pin GPIO_PIN_15
#define EOC_NEGADO_GPIO_Port GPIOB
#define CONVST_Pin GPIO_PIN_3
#define CONVST_GPIO_Port GPIOB
#define CS1_Pin GPIO_PIN_4
#define CS1_GPIO_Port GPIOB
#define CS2_Pin GPIO_PIN_5
#define CS2_GPIO_Port GPIOB
#define CS3_Pin GPIO_PIN_6
#define CS3_GPIO_Port GPIOB
#define RD_Pin GPIO_PIN_7
#define RD_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

#include "esp8266.h"
#include "stdlib.h"
#include <stdio.h>
#include <string.h>

#define CWJAP_CMD		"AT+CWJAP=\"test\",\"12345678\"\r\n"
#define CIPSTART_CMD	"AT+CIPSTART=\"UDP\",\"10.251.81.169\",8000,8001\r\n"
#define CIPSEND_CMD		"AT+CIPSEND="
#define CWMODE_CMD		"AT+CWMODE=1\r\n"
#define RESET_CMD 		"AT+RST\r\n"
#define READY_MSG		"ready"
#define SOK_MSG			"SEND OK\r\n"
#define OK_MSG			"OK\r\n"
#define WCONN_MSG		"WIFI CONNECTED\r\n"
#define CONN_MSG		"CONNECT\r\n"
#define WGIP_MSG		"WIFI GOT IP\r\n"
#define DATA_MSG		">\r\n"

static ESP8266_Status ESP_SendCommand(char *cmd, const char *ack, uint32_t timeout);
static ESP8266_Status ESP_DMA_Reset(void);
static uint16_t ESP_DMA_GetWritePos(void);

// DMA
#define ESP_DMA_RX_BUF_SIZE 256
static uint8_t esp_dma_rx_buf[ESP_DMA_RX_BUF_SIZE];
static char esp_rx_buffer[ESP_DMA_RX_BUF_SIZE];
static volatile uint16_t esp_dma_rx_head = 0;

ESP8266_Status ESP_Init(void)
{
	ESP8266_Status res;

	if (ESP_DMA_Reset() != ESP8266_OK){
		return ESP8266_ERROR;
	}

	res = ESP_SendCommand("AT+RST\r\n","ready",5000);
	if(res != ESP8266_OK){
		// Implementar debug
		return res;
	}
	res = ESP_SendCommand("ATE0\r\n","OK",2000);
	if(res != ESP8266_OK){
		// Implementar debug
		return res;
	}

	HAL_GPIO_WritePin(LED_OFF_GPIO_Port, LED_OFF_Pin, RESET);
	HAL_GPIO_WritePin(LED_ON_GPIO_Port, LED_ON_Pin, SET);
	HAL_GPIO_WritePin(LED_AMARILLO_GPIO_Port, LED_AMARILLO_Pin, SET);

	return ESP8266_OK;
}

ESP8266_Status ESP_ConnectWiFi_UDP(const char *ssid, const char *pss, const char *udp)
{
	char cmd[128];
	ESP8266_Status res;

	res = ESP_SendCommand("AT+CWMODE=1\r\n","OK",2000);
	if(res != ESP8266_OK){
		// Implementar debug
		return res;
	}

	snprintf(cmd, sizeof(cmd), "AT+CWJAP=\"%s\",\"%s\"\r\n",ssid,pss);
	res = ESP_SendCommand(cmd,"OK",10000);
	if(res != ESP8266_OK){
		// Implementar debug
		return res;
	}

	snprintf(cmd, sizeof(cmd), "AT+CIPSTART=\"UDP\",\"%s\",8000,8001\r\n",udp);
	res = ESP_SendCommand(cmd,"OK",10000);
	if(res != ESP8266_OK){
		// Implementar debug
		return res;
	}

	HAL_GPIO_WritePin(LED_OFF_GPIO_Port, LED_OFF_Pin, SET);
	HAL_GPIO_WritePin(LED_ON_GPIO_Port, LED_ON_Pin, RESET);

	return ESP8266_OK;
}

static ESP8266_Status ESP_SendCommand(char *cmd, const char *ack, uint32_t timeout)
{
    uint32_t tickstart = HAL_GetTick();

    if ((ack == NULL) || (*ack == '\0')) {
        return ESP8266_ERROR;
    }

    if ((ack == NULL) || (*ack == '\0')) {
        return ESP8266_ERROR;
    }

    if (ESP_DMA_Reset() != ESP8266_OK) {
        return ESP8266_ERROR;
    }

    if ((cmd != NULL) && (strlen(cmd) > 0U)) {
       // DEBUG_LOG("Sending: %s", cmd);
        if (HAL_UART_Transmit(&ESP_UART, (uint8_t*)cmd, strlen(cmd), HAL_MAX_DELAY) != HAL_OK)
            return ESP8266_ERROR;
    }

    while ((HAL_GetTick() - tickstart) < timeout)
    {
        uint16_t write_pos = ESP_DMA_GetWritePos();
        while (esp_dma_rx_head != write_pos)
        {
            char c = (char)esp_dma_rx_buf[esp_dma_rx_head++];
            if (esp_dma_rx_head >= ESP_DMA_RX_BUF_SIZE) {
                esp_dma_rx_head = 0;
            }

            size_t len = strlen(esp_rx_buffer);
            if (len >= sizeof(esp_rx_buffer) - 1U) {
                memset(esp_rx_buffer, 0, sizeof(esp_rx_buffer));
                len = 0;
            }

            esp_rx_buffer[len] = c;
            esp_rx_buffer[len + 1U] = '\0';

            if (strstr(esp_rx_buffer, ack) != NULL) {
                return ESP8266_OK;
            }
        }
        HAL_Delay(1);
    }

    //DEBUG_LOG("Timeout or no ACK. Buffer: %s", esp_dma_rx_buf);
    return ESP8266_TIMEOUT;
}

static ESP8266_Status ESP_DMA_Reset(void)
{
    (void)HAL_UART_DMAStop(&ESP_UART);

    __HAL_UART_CLEAR_OREFLAG(&ESP_UART);
    __HAL_UART_CLEAR_IDLEFLAG(&ESP_UART);
    __HAL_UART_FLUSH_DRREGISTER(&ESP_UART);

    memset(esp_dma_rx_buf, 0, sizeof(esp_dma_rx_buf));
    memset(esp_rx_buffer, 0, sizeof(esp_rx_buffer));
    esp_dma_rx_head = 0;

    if (HAL_UART_Receive_DMA(&ESP_UART, esp_dma_rx_buf, ESP_DMA_RX_BUF_SIZE) != HAL_OK) {
        return ESP8266_ERROR;
    }

    esp_dma_rx_head = ESP_DMA_GetWritePos();

    return ESP8266_OK;
}

static uint16_t ESP_DMA_GetWritePos(void)
{
    return ESP_DMA_RX_BUF_SIZE - __HAL_DMA_GET_COUNTER(ESP_UART.hdmarx);
}

#ifndef INC_ESP8266_H_
#define INC_ESP8266_H_

#include "main.h"

#define ESP_UART huart1 // huart que se usa para la ESP8266
extern UART_HandleTypeDef ESP_UART;

typedef enum {
	ESP8266_OK = 0,
	ESP8266_ERROR,
	ESP8266_TIMEOUT,
	ESP8266_NO_RESPONDE,
}ESP8266_Status;

ESP8266_Status ESP_Init(void);
ESP8266_Status ESP_ConnectWiFi_UDP(const char *ssid, const char *pss, const char *udp);

#endif /* INC_ESP8266_H_ */
